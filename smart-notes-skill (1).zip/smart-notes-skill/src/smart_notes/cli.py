import argparse
from .core import SmartNotes

DEFAULT_FILE = "notes.json"


def main(argv=None):
    ap = argparse.ArgumentParser(prog="smart-notes", description="จดบันทึกและจัดหมวดหมู่อัตโนมัติ")
    ap.add_argument("-f", "--file", default=DEFAULT_FILE)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add", help="เพิ่มบันทึก")
    a.add_argument("text")
    sub.add_parser("list", help="แสดงบันทึกตามหมวด")
    args = ap.parse_args(argv)

    sn = SmartNotes().load(args.file)
    if args.cmd == "add":
        n = sn.add(args.text)
        sn.save(args.file)
        print(f"[{n['category']}] {n['text']}")
    else:
        for cat, items in sn.by_category().items():
            print(f"## {cat}")
            for i in items:
                print(" -", i)


if __name__ == "__main__":
    main()
