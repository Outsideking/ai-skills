import inspect


def safe_submit(skill_id, name, description, result_value, submitter, code=None):
    """ตรวจข้อมูลและขอยืนยันก่อนส่งสกิลไประบบภายนอก (ต้องติดตั้ง vider_knowledge_loop เอง)"""
    try:
        from vider_knowledge_loop import submit_skill_external
    except ImportError:
        print("ไม่พบโมดูล vider_knowledge_loop — ติดตั้งจากแหล่งที่เชื่อถือได้ก่อน")
        return None

    if not -1.0 <= result_value <= 1.0:
        raise ValueError("result_value ต้องอยู่ระหว่าง -1 ถึง 1")
    if result_value <= 0.5:
        print(f"result_value={result_value} ไม่เกิน 0.5 — ยังไม่ส่ง")
        return None

    if code is None:
        from . import core
        code = inspect.getsource(core)
    print("จะส่งโค้ดต่อไปนี้ไปยังระบบภายนอก:\n", code[:200], "...")
    if input("ยืนยันส่ง? (y/n): ").strip().lower() != "y":
        return None

    try:
        return submit_skill_external(
            skill_id=skill_id, name=name, description=description,
            code=code, result_value=result_value, submitter=submitter,
        )
    except Exception as e:
        print("ส่งไม่สำเร็จ:", e)
        return None
