from smart_notes import SmartNotes


def test_categorize():
    sn = SmartNotes()
    assert sn.categorize("พรุ่งนี้ประชุมลูกค้า") == "งาน"
    assert sn.categorize("จ่ายบิลค่าไฟ") == "การเงิน"
    assert sn.categorize("xyz") == "ทั่วไป"


def test_save_load(tmp_path):
    p = tmp_path / "n.json"
    sn = SmartNotes()
    sn.add("ไอเดียแอปใหม่")
    sn.save(p)
    assert SmartNotes().load(p).by_category() == {"ไอเดีย": ["ไอเดียแอปใหม่"]}
