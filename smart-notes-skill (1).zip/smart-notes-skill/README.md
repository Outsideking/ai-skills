# smart-notes-skill

จดบันทึกและจัดหมวดหมู่อัตโนมัติ (งาน / การเงิน / ไอเดีย / ส่วนตัว / ทั่วไป) ไม่มี dependency ภายนอก

## ติดตั้ง
    pip install smart_notes_skill-0.1.0-py3-none-any.whl

## ใช้งาน
    smart-notes add "พรุ่งนี้ประชุมลูกค้า"
    smart-notes list

    from smart_notes import SmartNotes
    sn = SmartNotes(); sn.add("จ่ายบิลค่าไฟ")

## ส่งสกิล (ไม่บังคับ)
`smart_notes.safe_submit(...)` ต้องมี `vider_knowledge_loop` ติดตั้งแยก และจะขอยืนยันก่อนส่งโค้ดออกไปภายนอกทุกครั้ง

## ผู้พัฒนา
Thanva Phupingbut — ผู้ก่อตั้ง Genai
